#!/usr/bin/env python3
import sys
import subprocess

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, CancelResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from cobot_interfaces.action import CoMsgs

# Each legacy script creates/destroys its own rclpy context.
# If we run them in-process (runpy), DSR_ROBOT2's cached service clients
# can keep a dead context and crash on the next command.
# So we run each command in a fresh Python process: `python3 -m <module>`.

COMMANDS = {
    # kitchen items
    "cup": "kitchen_assistant.legacy.pick_and_place_cup_yolo",
    "컵": "kitchen_assistant.legacy.pick_and_place_cup_yolo",

    "ramen": "kitchen_assistant.legacy.pick_and_place_ramen_yolo",
    "라면": "kitchen_assistant.legacy.pick_and_place_ramen_yolo",

    "scissors": "kitchen_assistant.legacy.pick_and_place_scissors_yolo",
    "가위": "kitchen_assistant.legacy.pick_and_place_scissors_yolo",
    "주방가위": "kitchen_assistant.legacy.pick_and_place_scissors_yolo",

    "spatula": "kitchen_assistant.legacy.pick_and_place_spatula_yolo",
    "뒤집개": "kitchen_assistant.legacy.pick_and_place_spatula_yolo",

    "spoon": "kitchen_assistant.legacy.pick_and_place_spoon_yolo",
    "국자": "kitchen_assistant.legacy.pick_and_place_spoon_yolo",

    "knife": "kitchen_assistant.legacy.pick_and_place_knife",
    "칼": "kitchen_assistant.legacy.pick_and_place_knife",

    "pan": "kitchen_assistant.legacy.pick_and_place_pan_yolo",
    "프라이팬": "kitchen_assistant.legacy.pick_and_place_pan_yolo",
    "팬": "kitchen_assistant.legacy.pick_and_place_pan_yolo",

    "pot": "kitchen_assistant.legacy.pick_and_place_pot_yolo",
    "냄비": "kitchen_assistant.legacy.pick_and_place_pot_yolo",
}

# fridge sequences (open -> pick -> close)
FRIDGE_SEQ = {
    "apple": (
        "kitchen_assistant.legacy.fridge_rightdown_open",
        "kitchen_assistant.legacy.pick_and_place_apple_yolo",
        "kitchen_assistant.legacy.fridge_rightdown_close",
    ),
    "사과": (
        "kitchen_assistant.legacy.fridge_rightdown_open",
        "kitchen_assistant.legacy.pick_and_place_apple_yolo",
        "kitchen_assistant.legacy.fridge_rightdown_close",
    ),
    "orange": (
        "kitchen_assistant.legacy.fridge_leftdown_open",
        "kitchen_assistant.legacy.pick_and_place_orange_yolo",
        "kitchen_assistant.legacy.fridge_leftdown_close",
    ),
    "오렌지": (
        "kitchen_assistant.legacy.fridge_leftdown_open",
        "kitchen_assistant.legacy.pick_and_place_orange_yolo",
        "kitchen_assistant.legacy.fridge_leftdown_close",
    ),
    "bottle": (
        "kitchen_assistant.legacy.fridge_leftup_open",
        "kitchen_assistant.legacy.pick_and_place_bottle_yolo",
        "kitchen_assistant.legacy.fridge_leftup_close",
    ),
    "콜라": (
        "kitchen_assistant.legacy.fridge_leftup_open",
        "kitchen_assistant.legacy.pick_and_place_bottle_yolo",
        "kitchen_assistant.legacy.fridge_leftup_close",
    ),
    "페트병": (
        "kitchen_assistant.legacy.fridge_leftup_open",
        "kitchen_assistant.legacy.pick_and_place_bottle_yolo",
        "kitchen_assistant.legacy.fridge_leftup_close",
    ),
}


# def _normalize(s: str) -> str:
#     return s.strip()

# def _pick_key(cmd: str):
#     # fuzzy: if sentence contains one of keys
#     for k in FRIDGE_SEQ.keys():
#         if k in cmd:
#             return k
#     for k in COMMANDS.keys():
#         if k in cmd:
#             return k
#     return None

# def _run_module(mod: str) -> int:
#     cmd = [sys.executable, "-m", mod]
#     print(f"[CLI] exec: {' '.join(cmd)}")
#     return subprocess.call(cmd)

class KitchenActionServer(Node):
    def __init__(self):
        super().__init__('kitchen_assistant_action_server')
        self._action_server = ActionServer(
            self,
            CoMsgs,
            'kitchen_assistant_task',
            self.execute_callback,
            callback_group=ReentrantCallbackGroup(),
            cancel_callback=self.cancel_callback
        )
        self.current_process = None # 현재 실행 중인 subprocess
        self.get_logger().info("Kitchen Action Server Ready!")

    def cancel_callback(self, goal_handle):
        self.get_logger().warn("Cancel Requested! Killing subprocess...")
        # 실행 중인 프로세스가 있으면 강제 종료 (Kill)
        if self.current_process and self.current_process.poll() is None:
            self.current_process.terminate() # 혹은 .kill()
        return CancelResponse.ACCEPT

    def execute_callback(self, goal_handle):
        # 1. 요청받은 명령어 가져오기
        raw_cmd = goal_handle.request.task_name
        self.get_logger().info(f"📩 Goal Received: '{raw_cmd}'")
        
        feedback_msg = CoMsgs.Feedback()
        
        # 2. 키워드 매칭 (Fuzzy Match)
        key = self._pick_key(raw_cmd)
        
        if key is None:
            self.get_logger().warn(f"❌ Unknown command: {raw_cmd}")
            goal_handle.abort()
            return CoMsgs.Result(success=False, message=f"Unknown command: {raw_cmd}")

        # 3. 작업 실행 (시퀀스 or 단일)
        success_all = True
        error_msg = ""

        if key in FRIDGE_SEQ:
            steps = FRIDGE_SEQ[key]
            for i, mod in enumerate(steps):
                # 취소 체크
                if goal_handle.is_cancel_requested:
                    goal_handle.canceled()
                    return CoMsgs.Result(success=False, message="Canceled")

                # 피드백 전송
                feedback_msg.current_status = f"Running step {i+1}/{len(steps)}: {mod}"
                feedback_msg.step_current = i + 1
                feedback_msg.step_total = len(steps)
                goal_handle.publish_feedback(feedback_msg)

                # subprocess 실행
                if not self.run_process(mod):
                    success_all = False
                    error_msg = f"Failed at {mod}"
                    break # 시퀀스 중단

        elif key in COMMANDS:
            mod = COMMANDS[key]
            feedback_msg.current_status = f"Running: {mod}"
            feedback_msg.step_current = 1
            feedback_msg.step_total = 1
            goal_handle.publish_feedback(feedback_msg)
            
            if not self.run_process(mod):
                success_all = False
                error_msg = f"Failed at {mod}"

        # 4. 결과 보고
        if success_all:
            goal_handle.succeed()
            self.get_logger().info(f"✅ Task Completed: {key}")
            return CoMsgs.Result(success=True, message="Completed")
        else:
            goal_handle.abort()
            self.get_logger().error(f"❌ Task Failed: {key}")
            return CoMsgs.Result(success=False, message=error_msg)

    def run_process(self, mod_name):
        """subprocess를 실행하고 완료될 때까지 기다림"""
        cmd = [sys.executable, "-m", mod_name]
        try:
            # Popen으로 열어서 제어권 확보
            self.current_process = subprocess.Popen(cmd)
            self.current_process.wait() # 프로세스가 끝날 때까지 대기
            
            # 정상 종료(0) 확인
            return self.current_process.returncode == 0
        except Exception as e:
            self.get_logger().error(f"Execution Error: {e}")
            return False

    def _pick_key(self, cmd: str):
        """명령어에 키워드가 포함되어 있는지 확인 (Fuzzy Matching)"""
        if not cmd: return None
        # 1. 정확한 시퀀스 키 확인
        for k in FRIDGE_SEQ.keys():
            if k in cmd: return k
        # 2. 단일 명령어 확인
        for k in COMMANDS.keys():
            if k in cmd: return k
        return None

def main(args=None):
    # [수정] ROS 2 노드 실행 구조로 변경
    rclpy.init(args=args)
    
    kitchen_server = KitchenActionServer()
    
    # Action Server는 멀티스레드 Executor가 필수적임 (Cancellation 등을 위해)
    executor = MultiThreadedExecutor()
    executor.add_node(kitchen_server)
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        kitchen_server.get_logger().info('Keyboard Interrupt (SIGINT)')
    finally:
        kitchen_server.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
