import os
import time
import threading  # [NEW] 스레딩 모듈 추가
import rclpy
import pyaudio
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor

from ament_index_python.packages import get_package_share_directory
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate

# Trigger 서비스는 더 이상 사용하지 않으므로 제거하거나 주석 처리해도 됨
from std_srvs.srv import Trigger 

from cobot_interfaces.action import CoMsgs 

from voice_processing.MicController import MicController, MicConfig
from voice_processing.wakeup_word import WakeupWord
from voice_processing.stt import STT

############ 환경 설정 ############
try:
    package_path = get_package_share_directory("kitchen_assistant")
except:
    package_path = "."

env_path = os.path.join(package_path, "resource", ".env")
if os.path.exists(env_path):
    load_dotenv(dotenv_path=env_path)
    
openai_api_key = os.getenv("OPENAI_API_KEY")

############ GetKeyword Node ############
class GetKeyword(Node):
    def __init__(self):
        super().__init__("get_keyword_node")

        # 1. LLM 설정 (이전과 동일, 프롬프트는 '주방 용품' 기준)
        self.llm = ChatOpenAI(
            model="gpt-4o", temperature=0.1, openai_api_key=openai_api_key
        )

        prompt_content = """
            당신은 사용자의 문장에서 특정 도구와 목적지를 추출해야 합니다.

            <목표>
            - 문장에서 다음 리스트에 포함된 도구를 최대한 정확히 추출하세요.
            - 문장에 등장하는 도구의 목적지(어디로 옮기라고 했는지)도 함께 추출하세요.

            <대상 리스트>
            - pan, cup, ramen, knife, spoon, spatula, scissors, pot, bottle, apple, orange
            <출력 형식>
            - 반드시 다음 형식으로만 출력하세요: 대상1 대상2 ... / pos1 pos2 ...
            - 대상과 위치는 띄어쓰기로 구분합니다.
            - 대상이나 목적지가 없으면 해당 부분은 비워두고 '/' 기호는 유지하세요.
            - 리스트에 없는 단어는 절대 출력하지 마세요.

            <특수 규칙>
            - 한국어 동의어나 유사 발음도 리스트 내의 영어 단어로 매핑하세요. 
            (예: "사과", "애플" -> apple / "면", "라면" -> ramen / "콜라" -> bottle)

            <예시>
            - 입력: "bottle를 pos1에 가져다 놔"  
            출력: bottle / pos1

            - 입력: "사과랑 오렌지 식탁에 둬"  
            출력: apple orange /

            - 입력: "라면 끓여줘"  
            출력: ramen /

            - 입력: "컵을 pos2에 두고 칼은 pos1에 둬"  
            출력: cup knife / pos2 pos1
            
            - 입력: "왼쪽에 있는 가위 줘"
            출력: scissors /

            <사용자 입력>
            "{user_input}"                
        """

        self.prompt_template = PromptTemplate(
            input_variables=["user_input"], template=prompt_content
        )
        self.lang_chain = self.prompt_template | self.llm
        self.stt = STT(openai_api_key=openai_api_key)

        # 2. 오디오 설정
        mic_config = MicConfig(
            chunk=12000, rate=48000, channels=1, record_seconds=5,
            fmt=pyaudio.paInt16, device_index=10, buffer_size=24000,
        )
        self.mic_controller = MicController(config=mic_config)
        self.wakeup_word = WakeupWord(mic_config.buffer_size)

        # 3. Action Client
        self._action_client = ActionClient(self, CoMsgs, 'kitchen_assistant_task')

        # 4. [NEW] 백그라운드 리스닝 스레드 시작
        # 서비스 서버(Trigger) 대신, 노드가 켜지면 바로 듣기 시작합니다.
        self.listen_thread = threading.Thread(target=self.run_voice_loop)
        self.listen_thread.daemon = True # 노드가 죽으면 스레드도 같이 죽음
        self.listen_thread.start()

        self.get_logger().info("✅ MicRecorderNode Started. Listening in background...")

    def run_voice_loop(self):
        """별도 스레드에서 무한 반복하며 음성을 감지하는 함수"""
        
        # 스트림 열기 (한 번만 열어둠)
        try:
            self.mic_controller.open_stream()
            self.wakeup_word.set_stream(self.mic_controller.stream)
            self.get_logger().info("🎤 Microphone stream opened. Waiting for 'Hey Kakao'...")
        except Exception as e:
            self.get_logger().error(f"Failed to open mic: {e}")
            return

        while rclpy.ok():
            try:
                # 1. Wake-up Word 감지 대기
                if not self.wakeup_word.is_wakeup():
                    time.sleep(0.05) # CPU 점유율 방지
                    continue

                # 2. 감지됨! STT 시작
                self.get_logger().info("✨ Wake-word detected! Recording...")
                output_message = self.stt.speech2text()
                self.get_logger().info(f"🗣️  User said: {output_message}")

                # 3. LLM 키워드 추출
                keywords = self.extract_keyword(output_message)
                
                # 4. Action 전송
                if keywords:
                    primary_task = keywords[0]
                    self.get_logger().info(f"🤖 Order recognized: {primary_task}")
                    self.send_kitchen_goal(primary_task)
                else:
                    self.get_logger().warn("⚠️  No valid keyword detected.")
                
                # 다시 루프의 처음으로 돌아가서 대기...
                self.get_logger().info("👂 Listening again...")
                
            except Exception as e:
                self.get_logger().error(f"Error in voice loop: {e}")
                time.sleep(1.0) # 에러 발생 시 1초 쉬고 재시도

    def extract_keyword(self, output_message):
        try:
            response = self.lang_chain.invoke({"user_input": output_message})
            result = response.content
            
            # 전처리
            clean_result = result.replace("[", "").replace("]", "").replace("'", "").strip()
            if "/" not in clean_result:
                clean_result += " /"
            
            object_part, _ = clean_result.split("/", 1)
            objects = object_part.split()
            return objects
        except Exception as e:
            self.get_logger().error(f"LLM Parsing Error: {e}")
            return []

    def send_kitchen_goal(self, task_name):
        # Action Server가 떠있는지 확인
        if not self._action_client.wait_for_server(timeout_sec=1.0):
            self.get_logger().error("🚫 Kitchen Action Server is NOT active.")
            return

        goal_msg = CoMsgs.Goal()
        goal_msg.task_name = task_name

        self.get_logger().info(f"🚀 Sending Action Goal: '{task_name}'")
        
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        # 너무 자주 뜨면 주석 처리 가능
        self.get_logger().info(f"   ↳ [Kitchen Status] {feedback.current_status}")

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("❌ Order rejected.")
            return
        self.get_logger().info("✅ Order accepted by Kitchen.")

def main():
    rclpy.init()
    node = GetKeyword()
    
    # Action Client의 콜백(feedback, result)을 처리하기 위해 MultiThreadedExecutor 사용 권장
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()