import os
import time
import rclpy
import pyaudio
from rclpy.node import Node
from rclpy.action import ActionClient # [Action 추가]
from rclpy.executors import MultiThreadedExecutor

from ament_index_python.packages import get_package_share_directory
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate

from std_srvs.srv import Trigger
# [Action 추가] 인터페이스 임포트
from cobot_interfaces.action import CoMsgs 

from voice_processing.MicController import MicController, MicConfig
from voice_processing.wakeup_word import WakeupWord
from voice_processing.stt import STT

############ Package Path & Environment Setting ############
# 패키지 경로를 현재 패키지 이름에 맞게 수정
try:
    package_path = get_package_share_directory("kitchen_assistant")
except:
    package_path = "." # 로컬 테스트용

is_laod = load_dotenv(dotenv_path=os.path.join(f"{package_path}/resource/.env"))
openai_api_key = os.getenv("OPENAI_API_KEY")

############ GetKeyword Node ############
class GetKeyword(Node):
    def __init__(self):
        print("!!! NEW CODE RUNNING !!!")  # 이 메시지가 떠야 성공입니다
        super().__init__("get_keyword_node")

        self.llm = ChatOpenAI(
            model="gpt-4o", temperature=0.1, openai_api_key=openai_api_key
        )

        # [핵심 수정] 예시를 주방 용품에 맞게, 그리고 입력-출력이 일치하게 고쳤습니다.
        prompt_content = """
            당신은 사용자의 문장에서 특정 도구와 목적지를 추출해야 합니다.

            <목표>
            - 문장에서 다음 리스트에 포함된 도구를 최대한 정확히 추출하세요.
            - 문장에 등장하는 도구의 목적지(어디로 옮기라고 했는지)도 함께 추출하세요.

            <대상 리스트>
            - bottle, cup, knife, scissors, apple, orange, banana, ramen, spam, pot, frypan, spatula, spoon

            <출력 형식>
            - 반드시 다음 형식으로만 출력하세요: 대상1 대상2 ... / pos1 pos2 ...
            - 대상과 위치는 띄어쓰기로 구분합니다.
            - 대상이나 목적지가 없으면 해당 부분은 비워두고 '/' 기호는 유지하세요.
            - 대상과 목적지의 순서는 등장 순서를 따릅니다.
            - 리스트에 없는 단어는 절대 출력하지 마세요.

            <특수 규칙>
            - 한국어 동의어나 유사 발음도 리스트 내의 영어 단어로 매핑하세요. 
            (예: "사과", "애플" -> apple / "면", "라면" -> ramen / "콜라" -> bottle)

            <예시>
            - 입력: "bottle를 pos1에 가져다 놔"  
            출력: bottle / pos1

            - 입력: "사과랑 오렌지 식탁에 둬"  
            출력: apple orange /

            - 입력: "라면 끓여줘"  
            출력: ramen /

            - 입력: "컵을 pos2에 두고 칼은 pos1에 둬"  
            출력: cup knife / pos2 pos1
            
            - 입력: "왼쪽에 있는 가위 줘"
            출력: scissors /

            <사용자 입력>
            "{user_input}"                
        """

        self.prompt_template = PromptTemplate(
            input_variables=["user_input"], template=prompt_content
        )
        self.lang_chain = self.prompt_template | self.llm
        self.stt = STT(openai_api_key=openai_api_key)

        # 오디오 설정
        mic_config = MicConfig(
            chunk=12000, rate=48000, channels=1, record_seconds=5,
            fmt=pyaudio.paInt16, device_index=10, buffer_size=24000,
        )
        self.mic_controller = MicController(config=mic_config)
        self.wakeup_word = WakeupWord(mic_config.buffer_size)

        # Service Server
        self.get_keyword_srv = self.create_service(
            Trigger, "get_keyword", self.get_keyword
        )

        # [Action 추가] Action Client 설정
        self._action_client = ActionClient(self, CoMsgs, 'kitchen_assistant_task')

        self.get_logger().info("MicRecorderNode initialized & Action Client Ready.")

    def extract_keyword(self, output_message):
        response = self.lang_chain.invoke({"user_input": output_message})
        result = response.content

        # [디버깅] LLM이 실제로 뱉은 원본 문자열 확인 (매우 중요)
        print(f"DEBUG: LLM Raw Output -> '{result}'")

        try:
            # 대괄호 제거 등 전처리
            clean_result = result.replace("[", "").replace("]", "").replace("'", "").strip()
            
            if "/" not in clean_result:
                clean_result += " /"

            object_part, target_part = clean_result.split("/", 1)
            objects = object_part.split()
            targets = target_part.split()

            print(f"Parsed objects: {objects}")
            print(f"Parsed targets: {targets}")
            return objects
            
        except Exception as e:
            self.get_logger().error(f"Parsing Error: {e}")
            return []

    # [Action 추가] 주방으로 주문 전송
    def send_kitchen_goal(self, task_name):
        self.get_logger().info(f"🚀 Sending Goal to Kitchen: {task_name}")

        if not self._action_client.wait_for_server(timeout_sec=2.0):
            self.get_logger().error("Action Server not available!")
            return

        goal_msg = CoMsgs.Goal()
        goal_msg.task_name = task_name

        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f"👨‍🍳 Kitchen Update: {feedback.current_status}")

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("❌ Order rejected.")
            return
        self.get_logger().info("✅ Order accepted!")

    def get_keyword(self, request, response):
        try:
            print("open stream")
            self.mic_controller.open_stream()
            self.wakeup_word.set_stream(self.mic_controller.stream)
        except OSError:
            self.get_logger().error("Error: Failed to open audio stream")
            return None

        self.get_logger().info("Waiting for Wake-up word...")
        
        # [수정] CPU 점유율 방지
        while not self.wakeup_word.is_wakeup():
            time.sleep(0.05)

        output_message = self.stt.speech2text()
        self.get_logger().info(f"STT Result: {output_message}")
        
        keywords = self.extract_keyword(output_message) # ['apple'] 등이 나와야 함

        self.get_logger().warn(f"Detected tools: {keywords}")

        if keywords:
            # [Action 추가] 첫 번째 키워드를 액션 서버로 전송
            self.send_kitchen_goal(keywords[0])
            
            response.success = True
            response.message = f"Order sent: {keywords[0]}"
        else:
            response.success = False
            response.message = "No keyword detected"

        return response


def main():
    rclpy.init()
    node = GetKeyword()
    
    # [수정] 멀티스레드 실행기로 변경하여 Action 통신이 막히지 않게 함
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    
    try:
        executor.spin() # rclpy.spin(node) 대신 사용
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()