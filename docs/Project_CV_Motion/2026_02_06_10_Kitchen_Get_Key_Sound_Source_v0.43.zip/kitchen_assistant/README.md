\
# kitchen_assistant_ros2_ws

This workspace wraps your current working `python3` scripts into a ROS2 (Humble) `ament_python` package so you can run:

- `ros2 run kitchen_assistant kitchen_cli`
- `ros2 launch kitchen_assistant kitchen_cli.launch.py`

## 0) What is included
- `src/kitchen_assistant/kitchen_assistant/legacy/` : your original scripts (minimally patched for imports + model/resource path resolution)
- `src/kitchen_assistant/kitchen_assistant/models/` : uploaded .pt models included:
  - only_ramen_best.pt
  - kitchen.pt
  - potandhandle.pt
- `src/od_msg/` : service definition package (as you uploaded)

## 1) Missing files you must provide
- `yolo11n.pt` (many scripts reference it): place it in either:
  - `src/kitchen_assistant/kitchen_assistant/models/yolo11n.pt` (recommended), or
  - set env `KITCHEN_MODEL_DIR` to the folder containing it.
- `T_gripper2camera.npy` (hand-eye): place it in either:
  - your home `~/T_gripper2camera.npy`, or
  - any working dir you run from, or
  - set env `KITCHEN_RESOURCE_T_GRIPPER2CAMERA_NPY` to the full path.

## 2) Build
```bash
cd ~/cobot_ws   # or your workspace
# unzip this workspace somewhere, then:
cd kitchen_assistant_ros2_ws
colcon build --symlink-install
source install/setup.bash
```

## 3) Run (assumes Doosan bringup + RealSense already running)
Terminal A (Doosan):
```bash
ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=real host:=192.168.1.100 port:=12345 model:=m0609
```

Terminal B (RealSense):
```bash
ros2 launch realsense2_camera rs_launch.py
```

Terminal C (CLI):
```bash
source install/setup.bash
ros2 run kitchen_assistant kitchen_cli
```

Examples:
- `cup` / `컵`
- `ramen` / `라면`
- `pan` / `프라이팬`
- `apple` / `사과`  (runs: fridge_rightdown_open -> apple -> fridge_rightdown_close)
- `orange` / `오렌지` (leftdown)
- `bottle` / `콜라` (leftup)
